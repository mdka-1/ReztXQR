export type QRErrorLevel = 'L' | 'M' | 'Q' | 'H';

export interface ImageSettings {
  src: string;
  height: number;
  width: number;
  excavate: boolean;
  x?: number;
  y?: number;
}

export interface QROptions {
  value: string;
  size: number;
  fgColor: string;
  bgColor: string;
  level: QRErrorLevel;
  marginSize: number;
  imageSettings: ImageSettings | null;
}

export interface GeminiSuggestion {
    label: string;
    content: string;
}
