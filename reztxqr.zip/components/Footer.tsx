import React from 'react';

const Footer: React.FC = () => {
    return (
        <footer className="text-center py-8 px-4">
            <p className="text-sm text-gray-500 dark:text-gray-400">
                &copy; {new Date().getFullYear()} QR Code Studio Pro. Built with React, Tailwind CSS, and Gemini.
            </p>
        </footer>
    );
};

export default Footer;
