import React, { useState } from 'react';
import { QROptions, QRErrorLevel } from '../types';
import { ERROR_LEVELS, ERROR_LEVEL_DESCRIPTIONS } from '../constants';
import GeminiPanel from './GeminiPanel';
import { Icons } from './Icons';

interface ControlPanelProps {
    options: QROptions;
    onOptionChange: <K extends keyof QROptions>(option: K, value: QROptions[K]) => void;
    onImageUpload: (file: File | null) => void;
}

const ControlPanel: React.FC<ControlPanelProps> = ({ options, onOptionChange, onImageUpload }) => {
    const handleImageFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        onImageUpload(file || null);
    };
    
    return (
        <div className="space-y-6">
            <ControlSection title="Content" icon={<Icons.Text className="w-5 h-5" />}>
                <textarea
                    value={options.value}
                    onChange={(e) => onOptionChange('value', e.target.value)}
                    rows={4}
                    className="w-full p-2 bg-gray-200 dark:bg-gray-800 border border-gray-300 dark:border-gray-700 rounded-md focus:ring-2 focus:ring-sky-500 focus:border-sky-500 transition"
                    placeholder="Enter URL, text, or data..."
                />
            </ControlSection>

            <GeminiPanel onSuggestionSelect={(content) => onOptionChange('value', content)} />

            <ControlSection title="Styling" icon={<Icons.Palette className="w-5 h-5" />}>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <ColorInput label="Foreground" value={options.fgColor} onChange={(color) => onOptionChange('fgColor', color)} />
                    <ColorInput label="Background" value={options.bgColor} onChange={(color) => onOptionChange('bgColor', color)} />
                </div>
            </ControlSection>

            <ControlSection title="Logo" icon={<Icons.Image className="w-5 h-5" />}>
                <div className="space-y-4">
                    <input
                        type="file"
                        accept="image/png, image/jpeg, image/svg+xml"
                        onChange={handleImageFileChange}
                        className="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-sky-50 file:text-sky-700 hover:file:bg-sky-100 dark:file:bg-sky-900/50 dark:file:text-sky-300 dark:hover:file:bg-sky-900"
                    />
                    {options.imageSettings && (
                        <div className="flex items-center justify-between bg-gray-200 dark:bg-gray-800 p-2 rounded-md">
                            <span className="text-sm">Clear space for logo</span>
                            <label className="relative inline-flex items-center cursor-pointer">
                                <input type="checkbox" checked={options.imageSettings.excavate} onChange={(e) => onOptionChange('imageSettings', { ...options.imageSettings!, excavate: e.target.checked })} className="sr-only peer" />
                                <div className="w-11 h-6 bg-gray-300 dark:bg-gray-700 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-sky-300 dark:peer-focus:ring-sky-800 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-sky-600"></div>
                            </label>
                        </div>
                    )}
                </div>
            </ControlSection>

            <ControlSection title="Advanced" icon={<Icons.Sliders className="w-5 h-5" />}>
                <div className="space-y-4">
                    <RangeInput label="Size" value={options.size} min={64} max={1024} step={8} onChange={(val) => onOptionChange('size', val)} unit="px" />
                    <RangeInput label="Margin" value={options.marginSize} min={0} max={40} step={1} onChange={(val) => onOptionChange('marginSize', val)} unit="px" />
                    <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Error Correction</label>
                        <select
                            value={options.level}
                            onChange={(e) => onOptionChange('level', e.target.value as QRErrorLevel)}
                            className="w-full p-2 bg-gray-200 dark:bg-gray-800 border border-gray-300 dark:border-gray-700 rounded-md focus:ring-2 focus:ring-sky-500 focus:border-sky-500 transition"
                        >
                            {ERROR_LEVELS.map(level => (
                                <option key={level} value={level}>{ERROR_LEVEL_DESCRIPTIONS[level]}</option>
                            ))}
                        </select>
                    </div>
                </div>
            </ControlSection>
        </div>
    );
};


const ControlSection: React.FC<{ title: string; icon: React.ReactNode; children: React.ReactNode }> = ({ title, icon, children }) => {
    const [isOpen, setIsOpen] = useState(true);

    return (
        <div className="bg-white dark:bg-gray-900 rounded-lg shadow-sm transition">
            <button onClick={() => setIsOpen(!isOpen)} className="w-full flex justify-between items-center p-4 text-left font-semibold text-gray-800 dark:text-gray-200">
                <div className="flex items-center gap-3">
                    {icon}
                    <span>{title}</span>
                </div>
                <Icons.ChevronDown className={`w-5 h-5 transform transition-transform ${isOpen ? 'rotate-180' : ''}`} />
            </button>
            {isOpen && <div className="p-4 border-t border-gray-200 dark:border-gray-800">{children}</div>}
        </div>
    );
};

const ColorInput: React.FC<{ label: string; value: string; onChange: (value: string) => void; }> = ({ label, value, onChange }) => (
    <div>
        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">{label}</label>
        <div className="mt-1 flex items-center gap-2">
            <div className="relative">
                <input
                    type="color"
                    value={value}
                    onChange={(e) => onChange(e.target.value)}
                    className="w-10 h-10 p-0 border-none rounded-md cursor-pointer appearance-none bg-transparent [&::-webkit-color-swatch-wrapper]:p-0 [&::-webkit-color-swatch]:rounded-md [&::-webkit-color-swatch]:border-none"
                />
            </div>
            <input
                type="text"
                value={value}
                onChange={(e) => onChange(e.target.value)}
                className="w-full p-2 bg-gray-200 dark:bg-gray-800 border border-gray-300 dark:border-gray-700 rounded-md text-sm"
            />
        </div>
    </div>
);

const RangeInput: React.FC<{ label: string; value: number; min: number; max: number; step: number; onChange: (value: number) => void; unit: string; }> = ({ label, value, min, max, step, onChange, unit }) => (
    <div>
        <div className="flex justify-between items-center mb-1">
            <label className="text-sm font-medium text-gray-700 dark:text-gray-300">{label}</label>
            <span className="text-sm font-mono text-sky-600 dark:text-sky-400">{value}{unit}</span>
        </div>
        <input
            type="range"
            min={min}
            max={max}
            step={step}
            value={value}
            onChange={(e) => onChange(Number(e.target.value))}
            className="w-full h-2 bg-gray-200 dark:bg-gray-700 rounded-lg appearance-none cursor-pointer accent-sky-600"
        />
    </div>
);

export default ControlPanel;
