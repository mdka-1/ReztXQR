import React, { useState } from 'react';
import { GeminiSuggestion } from '../types';
import { getQRCodeIdeas } from '../services/geminiService';
import { Icons } from './Icons';

interface GeminiPanelProps {
    onSuggestionSelect: (content: string) => void;
}

const GeminiPanel: React.FC<GeminiPanelProps> = ({ onSuggestionSelect }) => {
    const [topic, setTopic] = useState('');
    const [suggestions, setSuggestions] = useState<GeminiSuggestion[]>([]);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);

    const handleGenerate = async () => {
        if (!topic.trim()) {
            setError('Please enter a topic.');
            return;
        }
        setLoading(true);
        setError(null);
        setSuggestions([]);
        try {
            const result = await getQRCodeIdeas(topic);
            setSuggestions(result);
        } catch (e) {
            setError('Failed to get ideas. Please try again.');
            console.error(e);
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="bg-white dark:bg-gray-900 rounded-lg shadow-sm p-4 space-y-3">
            <div className="flex items-center gap-3 font-semibold text-gray-800 dark:text-gray-200">
                <Icons.Sparkles className="w-5 h-5 text-purple-500" />
                <span>Get AI Content Ideas</span>
            </div>
            <div className="flex gap-2">
                <input
                    type="text"
                    value={topic}
                    onChange={(e) => setTopic(e.target.value)}
                    placeholder="e.g., my coffee shop"
                    className="flex-grow p-2 bg-gray-200 dark:bg-gray-800 border border-gray-300 dark:border-gray-700 rounded-md focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition"
                    disabled={loading}
                />
                <button
                    onClick={handleGenerate}
                    disabled={loading}
                    className="px-4 py-2 bg-purple-600 text-white rounded-md font-semibold hover:bg-purple-700 disabled:bg-purple-400 dark:disabled:bg-purple-800 disabled:cursor-not-allowed transition flex items-center justify-center"
                >
                    {loading ? <Icons.Loader className="w-5 h-5 animate-spin" /> : 'Generate'}
                </button>
            </div>
            {error && <p className="text-sm text-red-500">{error}</p>}
            {suggestions.length > 0 && (
                <div className="grid grid-cols-2 gap-2 pt-2">
                    {suggestions.map((suggestion, index) => (
                        <button
                            key={index}
                            onClick={() => onSuggestionSelect(suggestion.content)}
                            className="text-left text-sm p-2 bg-gray-100 dark:bg-gray-800 hover:bg-gray-200 dark:hover:bg-gray-700 rounded-md transition"
                        >
                            <span className="font-semibold block">{suggestion.label}</span>
                        </button>
                    ))}
                </div>
            )}
        </div>
    );
};

export default GeminiPanel;
