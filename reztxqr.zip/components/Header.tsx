import React from 'react';
import { Icons } from './Icons';

interface HeaderProps {
    theme: string;
    toggleTheme: () => void;
}

const Header: React.FC<HeaderProps> = ({ theme, toggleTheme }) => {
    return (
        <header className="bg-white/70 dark:bg-gray-900/70 backdrop-blur-lg sticky top-0 z-10 shadow-sm">
            <div className="container mx-auto px-4 md:px-8 py-4 flex justify-between items-center">
                <div className="flex items-center gap-3">
                    <Icons.QRCode className="w-8 h-8 text-sky-500" />
                    <h1 className="text-2xl font-bold text-gray-900 dark:text-white">
                        QR Code Studio <span className="text-sky-500">Pro</span>
                    </h1>
                </div>
                <button
                    onClick={toggleTheme}
                    className="p-2 rounded-full text-gray-500 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-gray-800 focus:outline-none focus:ring-2 focus:ring-sky-500"
                    aria-label="Toggle theme"
                >
                    {theme === 'light' ? <Icons.Moon className="w-6 h-6" /> : <Icons.Sun className="w-6 h-6" />}
                </button>
            </div>
        </header>
    );
};

export default Header;
