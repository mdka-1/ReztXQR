import React, { useRef } from 'react';
import { QRCode } from 'react-qrcode-logo';
import { QROptions } from '../types';
import { Icons } from './Icons';

interface QRCodeCanvasProps {
    options: QROptions;
}

const QRCodeCanvas: React.FC<QRCodeCanvasProps> = ({ options }) => {
    const qrRef = useRef<any>(null);

    const handleDownload = () => {
        const canvas = document.getElementById('react-qrcode-logo') as HTMLCanvasElement;
        if (canvas) {
            const pngUrl = canvas
                .toDataURL("image/png")
                .replace("image/png", "image/octet-stream");
            const downloadLink = document.createElement("a");
            downloadLink.href = pngUrl;
            downloadLink.download = "qrcode.png";
            document.body.appendChild(downloadLink);
            downloadLink.click();
            document.body.removeChild(downloadLink);
        }
    };
    
    return (
        <div className="bg-white dark:bg-gray-900 rounded-lg shadow-sm p-6 lg:p-8 flex flex-col items-center justify-center sticky top-24">
            <div className="w-full max-w-sm aspect-square bg-gray-50 dark:bg-gray-800 rounded-md flex items-center justify-center p-4">
                <QRCode
                    id="react-qrcode-logo"
                    value={options.value}
                    size={options.size}
                    fgColor={options.fgColor}
                    bgColor={options.bgColor}
                    ecLevel={options.level}
                    qrStyle="squares"
                    quietZone={options.marginSize}
                    logoImage={options.imageSettings?.src}
                    logoWidth={options.imageSettings ? options.imageSettings.width * (options.size/256) : undefined}
                    logoHeight={options.imageSettings ? options.imageSettings.height * (options.size/256) : undefined}
                    removeQrCodeBehindLogo={options.imageSettings?.excavate}
                    logoPadding={2}
                    logoPaddingStyle='circle'
                />
            </div>
            <button
                onClick={handleDownload}
                className="mt-6 w-full max-w-sm inline-flex items-center justify-center px-6 py-3 border border-transparent text-base font-medium rounded-md shadow-sm text-white bg-sky-600 hover:bg-sky-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-sky-500 dark:focus:ring-offset-gray-900 transition"
            >
                <Icons.Download className="w-5 h-5 mr-2" />
                Download QR Code
            </button>
        </div>
    );
};

export default QRCodeCanvas;
