import { GoogleGenAI, Type } from "@google/genai";
import { GeminiSuggestion } from '../types';

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  console.warn("Gemini API key not found. AI features will be disabled.");
}

const ai = new GoogleGenAI({ apiKey: API_KEY! });

const schema = {
  type: Type.ARRAY,
  items: {
    type: Type.OBJECT,
    properties: {
      label: {
        type: Type.STRING,
        description: 'A short, user-friendly label for the content type (e.g., "Website Link").'
      },
      content: {
        type: Type.STRING,
        description: 'The actual data to be encoded in the QR code (e.g., a URL, vCard data).'
      },
    },
    required: ['label', 'content'],
  },
};

export async function getQRCodeIdeas(topic: string): Promise<GeminiSuggestion[]> {
  if (!API_KEY) {
    throw new Error("API key is not configured.");
  }
  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: `You are an expert in marketing and QR codes. A user wants to create a QR code for "${topic}". Suggest 4 diverse and useful types of content to encode. For each suggestion, provide a clear label and the example content itself. Examples include a website link, a vCard for contact info, a Wi-Fi login, an email, or a calendar event.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: schema,
      },
    });

    const jsonText = response.text.trim();
    const suggestions = JSON.parse(jsonText);
    return suggestions as GeminiSuggestion[];

  } catch (error) {
    console.error("Error calling Gemini API:", error);
    throw new Error("Failed to fetch suggestions from Gemini.");
  }
}
