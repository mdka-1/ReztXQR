import { QROptions, QRErrorLevel } from './types';

export const DEFAULT_QR_OPTIONS: QROptions = {
  value: 'https://github.com/google/gemini-api',
  size: 320,
  fgColor: '#0f172a',
  bgColor: '#ffffff',
  level: 'L',
  marginSize: 10,
  imageSettings: null,
};

export const ERROR_LEVELS: QRErrorLevel[] = ['L', 'M', 'Q', 'H'];

export const ERROR_LEVEL_DESCRIPTIONS: Record<QRErrorLevel, string> = {
    L: 'Low (recovers ~7% data)',
    M: 'Medium (recovers ~15% data)',
    Q: 'Quartile (recovers ~25% data)',
    H: 'High (recovers ~30% data)',
};
