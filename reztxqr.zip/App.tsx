import React, { useState, useCallback } from 'react';
import { QROptions } from './types';
import { DEFAULT_QR_OPTIONS } from './constants';
import Header from './components/Header';
import ControlPanel from './components/ControlPanel';
import QRCodeCanvas from './components/QRCodeCanvas';
import Footer from './components/Footer';

function App() {
  const [qrOptions, setQrOptions] = useState<QROptions>(DEFAULT_QR_OPTIONS);
  const [theme, setTheme] = useState('dark');

  const toggleTheme = () => {
    const newTheme = theme === 'light' ? 'dark' : 'light';
    setTheme(newTheme);
    if (newTheme === 'dark') {
      document.documentElement.classList.add('dark');
      setQrOptions(prev => ({ ...prev, fgColor: '#FFFFFF', bgColor: '#1e293b' }));
    } else {
      document.documentElement.classList.remove('dark');
      setQrOptions(prev => ({ ...prev, fgColor: '#0f172a', bgColor: '#FFFFFF' }));
    }
  };

  React.useEffect(() => {
    document.documentElement.classList.add('dark');
  }, []);

  const handleOptionsChange = useCallback(<K extends keyof QROptions>(option: K, value: QROptions[K]) => {
    setQrOptions(prevOptions => ({
      ...prevOptions,
      [option]: value,
    }));
  }, []);

  const handleImageUpload = useCallback((file: File | null) => {
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        handleOptionsChange('imageSettings', {
          src: reader.result as string,
          height: 48,
          width: 48,
          excavate: true,
        });
      };
      reader.readAsDataURL(file);
    } else {
      handleOptionsChange('imageSettings', null);
    }
  }, [handleOptionsChange]);

  return (
    <div className="min-h-screen bg-gray-100 dark:bg-gray-950 text-gray-800 dark:text-gray-200 font-sans">
      <Header theme={theme} toggleTheme={toggleTheme} />
      <main className="p-4 md:p-8">
        <div className="container mx-auto grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-1">
            <ControlPanel
              options={qrOptions}
              onOptionChange={handleOptionsChange}
              onImageUpload={handleImageUpload}
            />
          </div>
          <div className="lg:col-span-2">
            <QRCodeCanvas options={qrOptions} />
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}

export default App;
