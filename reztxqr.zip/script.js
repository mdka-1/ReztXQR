import React from 'react';
import { createRoot } from 'react-dom/client';
import { QRCode } from 'react-qrcode-logo';
import { GoogleGenAI, Type } from "@google/genai";

function App() {
    // === CONSTANTS ===
    const DEFAULT_QR_OPTIONS = {
        value: 'https://gemini.google.com',
        size: 320,
        fgColor: '#FFFFFF',
        bgColor: '#1e293b',
        level: 'L',
        marginSize: 10,
        imageSettings: null,
    };
    const ERROR_LEVELS = ['L', 'M', 'Q', 'H'];
    const ERROR_LEVEL_DESCRIPTIONS = {
        L: 'Low (recovers ~7% data)',
        M: 'Medium (recovers ~15% data)',
        Q: 'Quartile (recovers ~25% data)',
        H: 'High (recovers ~30% data)',
    };
    const GEMINI_SCHEMA = {
        type: Type.ARRAY,
        items: {
            type: Type.OBJECT,
            properties: {
                label: { type: Type.STRING, description: 'A short, user-friendly label for the content type (e.g., "Website Link").' },
                content: { type: Type.STRING, description: 'The actual data to be encoded in the QR code (e.g., a URL, vCard data).' },
            },
            required: ['label', 'content'],
        },
    };

    // === STATE ===
    let qrOptions = { ...DEFAULT_QR_OPTIONS };
    let currentTheme = 'dark';
    let qrCodeRoot = null;
    let ai = null;

    // === DOM SELECTORS ===
    const DOMElements = {};
    const elementIds = [
        'theme-toggle', 'theme-icon-sun', 'theme-icon-moon', 'qr-value', 'ai-topic', 'ai-generate-btn', 'ai-generate-text',
        'ai-loader', 'ai-error', 'ai-suggestions', 'fg-color-picker', 'fg-color-text', 'bg-color-picker', 'bg-color-text',
        'logo-upload', 'logo-options', 'logo-excavate', 'size-value', 'qr-size', 'margin-value', 'qr-margin', 'qr-level',
        'qrcode-container', 'download-btn'
    ];
    
    // === GEMINI AI LOGIC ===
    function initAI() {
        try {
            const API_KEY = process.env.API_KEY;
            if (API_KEY) {
                ai = new GoogleGenAI({ apiKey: API_KEY });
            } else {
                console.warn("Gemini API key not found. AI features will be disabled.");
                DOMElements['ai-generate-btn'].disabled = true;
                DOMElements['ai-topic'].disabled = true;
                DOMElements['ai-topic'].placeholder = 'AI disabled: No API Key';
            }
        } catch (e) {
            console.error("Failed to initialize Gemini AI:", e);
        }
    }
    
    async function getQRCodeIdeas(topic) {
        if (!ai) throw new Error("API key is not configured.");
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: `You are an expert in marketing and QR codes. A user wants to create a QR code for "${topic}". Suggest 4 diverse and useful types of content to encode. For each suggestion, provide a clear label and the example content itself. Examples include a website link, a vCard for contact info, a Wi-Fi login, an email, or a calendar event.`,
            config: {
                responseMimeType: "application/json",
                responseSchema: GEMINI_SCHEMA,
            },
        });
        return JSON.parse(response.text.trim());
    }

    async function handleAIGenerate() {
        const topic = DOMElements['ai-topic'].value.trim();
        if (!topic) {
            DOMElements['ai-error'].textContent = 'Please enter a topic.';
            return;
        }
        setAILoading(true);
        DOMElements['ai-error'].textContent = '';
        DOMElements['ai-suggestions'].innerHTML = '';
        try {
            const result = await getQRCodeIdeas(topic);
            displayAISuggestions(result);
        } catch (e) {
            DOMElements['ai-error'].textContent = 'Failed to get ideas. Please try again.';
            console.error(e);
        } finally {
            setAILoading(false);
        }
    }

    function setAILoading(isLoading) {
        DOMElements['ai-generate-btn'].disabled = isLoading;
        DOMElements['ai-topic'].disabled = isLoading;
        DOMElements['ai-generate-text'].classList.toggle('hidden', isLoading);
        DOMElements['ai-loader'].classList.toggle('hidden', !isLoading);
    }
    
    function displayAISuggestions(suggestions) {
        DOMElements['ai-suggestions'].innerHTML = '';
        suggestions.forEach(suggestion => {
            const button = document.createElement('button');
            button.className = "text-left text-sm p-2 bg-gray-100 dark:bg-gray-800 hover:bg-gray-200 dark:hover:bg-gray-700 rounded-md transition";
            button.innerHTML = `<span class="font-semibold block">${suggestion.label}</span>`;
            button.onclick = () => {
                handleOptionChange('value', suggestion.content);
            };
            DOMElements['ai-suggestions'].appendChild(button);
        });
    }

    // === RENDER/UPDATE LOGIC ===
    function renderQRCode() {
        if (!qrCodeRoot) {
            const container = DOMElements['qrcode-container'];
            if (container) qrCodeRoot = createRoot(container);
        }
        if (qrCodeRoot) {
            const props = {
                id: 'react-qrcode-logo',
                value: qrOptions.value,
                size: qrOptions.size,
                fgColor: qrOptions.fgColor,
                bgColor: qrOptions.bgColor,
                ecLevel: qrOptions.level,
                qrStyle: "squares",
                quietZone: qrOptions.marginSize,
                logoImage: qrOptions.imageSettings?.src,
                logoWidth: qrOptions.imageSettings ? qrOptions.imageSettings.width * (qrOptions.size / 256) : undefined,
                logoHeight: qrOptions.imageSettings ? qrOptions.imageSettings.height * (qrOptions.size / 256) : undefined,
                removeQrCodeBehindLogo: qrOptions.imageSettings?.excavate,
                logoPadding: 2,
                logoPaddingStyle: 'circle'
            };
            qrCodeRoot.render(React.createElement(QRCode, props));
        }
    }

    function updateUI() {
        DOMElements['qr-value'].value = qrOptions.value;
        DOMElements['fg-color-picker'].value = qrOptions.fgColor;
        DOMElements['fg-color-text'].value = qrOptions.fgColor;
        DOMElements['bg-color-picker'].value = qrOptions.bgColor;
        DOMElements['bg-color-text'].value = qrOptions.bgColor;
        DOMElements['qr-size'].value = qrOptions.size;
        DOMElements['size-value'].textContent = `${qrOptions.size}px`;
        DOMElements['qr-margin'].value = qrOptions.marginSize;
        DOMElements['margin-value'].textContent = `${qrOptions.marginSize}px`;
        DOMElements['qr-level'].value = qrOptions.level;
        DOMElements['logo-options'].classList.toggle('hidden', !qrOptions.imageSettings);
        if (qrOptions.imageSettings) {
            DOMElements['logo-excavate'].checked = qrOptions.imageSettings.excavate;
        }
    }

    // === EVENT HANDLERS ===
    function handleOptionChange(option, value) {
        if (option === 'imageSettings') {
             qrOptions.imageSettings = value ? { ...qrOptions.imageSettings, ...value } : null;
        } else {
            qrOptions[option] = value;
        }
        updateUI();
        renderQRCode();
    }

    function handleImageUpload(file) {
        if (file) {
            const reader = new FileReader();
            reader.onloadend = () => {
                handleOptionChange('imageSettings', { src: reader.result, height: 48, width: 48, excavate: true });
            };
            reader.readAsDataURL(file);
        } else {
            handleOptionChange('imageSettings', null);
        }
    }

    function handleDownload() {
        const canvas = document.getElementById('react-qrcode-logo');
        if (canvas) {
            const pngUrl = canvas.toDataURL("image/png").replace("image/png", "image/octet-stream");
            const downloadLink = document.createElement("a");
            downloadLink.href = pngUrl;
            downloadLink.download = "ReztXQR.png";
            document.body.appendChild(downloadLink);
            downloadLink.click();
            document.body.removeChild(downloadLink);
        }
    }

    function toggleTheme() {
        currentTheme = currentTheme === 'light' ? 'dark' : 'light';
        document.documentElement.classList.toggle('dark', currentTheme === 'dark');
        DOMElements['theme-icon-sun'].classList.toggle('hidden', currentTheme === 'dark');
        DOMElements['theme-icon-moon'].classList.toggle('hidden', currentTheme === 'light');

        const newColors = currentTheme === 'dark' 
            ? { fgColor: '#FFFFFF', bgColor: '#1e293b' } 
            : { fgColor: '#0f172a', bgColor: '#FFFFFF' };
        
        handleOptionChange('fgColor', newColors.fgColor);
        handleOptionChange('bgColor', newColors.bgColor);
    }
    
    // === INITIALIZATION ===
    function init() {
        elementIds.forEach(id => DOMElements[id] = document.getElementById(id));
        initAI();
        
        // Populate error correction dropdown
        ERROR_LEVELS.forEach(level => {
            const option = document.createElement('option');
            option.value = level;
            option.textContent = ERROR_LEVEL_DESCRIPTIONS[level];
            DOMElements['qr-level'].appendChild(option);
        });

        // Attach event listeners
        DOMElements['theme-toggle'].addEventListener('click', toggleTheme);
        DOMElements['qr-value'].addEventListener('input', e => handleOptionChange('value', e.target.value));
        DOMElements['fg-color-picker'].addEventListener('input', e => handleOptionChange('fgColor', e.target.value));
        DOMElements['fg-color-text'].addEventListener('input', e => handleOptionChange('fgColor', e.target.value));
        DOMElements['bg-color-picker'].addEventListener('input', e => handleOptionChange('bgColor', e.target.value));
        DOMElements['bg-color-text'].addEventListener('input', e => handleOptionChange('bgColor', e.target.value));
        DOMElements['qr-size'].addEventListener('input', e => handleOptionChange('size', Number(e.target.value)));
        DOMElements['qr-margin'].addEventListener('input', e => handleOptionChange('marginSize', Number(e.target.value)));
        DOMElements['qr-level'].addEventListener('change', e => handleOptionChange('level', e.target.value));
        DOMElements['logo-upload'].addEventListener('change', e => handleImageUpload(e.target.files?.[0] || null));
        DOMElements['logo-excavate'].addEventListener('change', e => handleOptionChange('imageSettings', { excavate: e.target.checked }));
        DOMElements['download-btn'].addEventListener('click', handleDownload);
        DOMElements['ai-generate-btn'].addEventListener('click', handleAIGenerate);
        
        document.querySelectorAll('.control-section-header').forEach(header => {
            header.addEventListener('click', () => {
                const content = header.nextElementSibling;
                const chevron = header.querySelector('.chevron');
                content.classList.toggle('hidden');
                if (content.classList.contains('hidden')) {
                     chevron.classList.remove('rotate-180');
                } else {
                     content.style.display = 'block';
                     chevron.classList.add('rotate-180');
                }
            });
        });
        
        // Set initial state
        DOMElements['theme-icon-sun'].classList.toggle('hidden', currentTheme === 'dark');
        DOMElements['theme-icon-moon'].classList.toggle('hidden', currentTheme === 'light');
        document.querySelectorAll('.control-section-content').forEach(el => el.classList.remove('hidden'));


        // Initial render
        updateUI();
        renderQRCode();
    }

    init();
}

document.addEventListener('DOMContentLoaded', App);
